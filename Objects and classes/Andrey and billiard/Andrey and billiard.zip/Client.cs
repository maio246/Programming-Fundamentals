﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Andrey_and_billiard
{
    class Client
    {
        public string Name { get; set; }

        public Dictionary<string, double> ShopList { get; set; }

        public double Bill { get; set; }

    }
}

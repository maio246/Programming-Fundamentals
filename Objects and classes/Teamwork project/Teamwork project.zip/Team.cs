﻿using System.Collections.Generic;

namespace Teamwork_project
{
    class Team
    {
        public  string TeamName { get; set; }

        public List<string> MembersList { get; set; }

        public string CreatorName { get; set; }

    }
}
